#include <Wire.h>
#include <LiquidCrystal_I2C.h>



LiquidCrystal_I2C lcd(0x27,2,1,0,3,4,5,6,7,POSITIVE );




void setup()
{
  Serial.begin ( 9600 );

 
  lcd.backlight();
    
  lcd.begin(16,2);               
  

  lcd.home ();                   
  lcd.print(" 0.000000008 ");  
  lcd.setCursor ( 0, 1 );       
   
}

void loop()
{
 
}
