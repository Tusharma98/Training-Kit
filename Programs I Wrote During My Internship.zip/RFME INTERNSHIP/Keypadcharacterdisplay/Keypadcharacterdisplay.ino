void setup() {
  Serial.begin(9600);

  pinMode(12, OUTPUT); // row
  pinMode(4, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(13, OUTPUT);

  digitalWrite(12, HIGH);
  digitalWrite(4, HIGH);
  digitalWrite(6, HIGH);
  digitalWrite(13, HIGH);

  pinMode(9, INPUT_PULLUP); // column
  pinMode(8, INPUT_PULLUP);
  pinMode(10, INPUT_PULLUP);
  pinMode(1, INPUT_PULLUP);

}
void loop() {
  digitalWrite(4,LOW);
  
  if (digitalRead(8) == LOW) {
    Serial.println("Pressed 7");
    delay(500);
  }
    
  if (digitalRead(9) == LOW) {
    Serial.println("Pressed 8");
    delay(500);
  } 
 
  if (digitalRead(10) == LOW) {
    Serial.println("Pressed 9");
    delay(500);
  }  
  
  if (digitalRead(1) == LOW) {
    Serial.println("Pressed A");
    delay(500);
  }

    digitalWrite(4,HIGH);

    digitalWrite(12,LOW);
  
  if (digitalRead(8) == LOW) {
    Serial.println("Pressed 4");
    delay(500);
  }
    
  if (digitalRead(9) == LOW) {
    Serial.println("Pressed 5");
    delay(500);
  } 
 
  if (digitalRead(10) == LOW) {
    Serial.println("Pressed 6");
    delay(500);
  }
  
  if (digitalRead(1) == LOW) {
    Serial.println("Pressed B");
    delay(500);
  }

    digitalWrite(12,HIGH);

     digitalWrite(6,LOW);
  
  if (digitalRead(8) == LOW) {
    Serial.println("Pressed 1");
    delay(500);
  }
    
  if (digitalRead(9) == LOW) {
    Serial.println("Pressed 2");
    delay(500);
  }
 
  if (digitalRead(10) == LOW) {
    Serial.println("Pressed 3");
    delay(500);
   
  }
  if (digitalRead(1) == LOW) {
    Serial.println("Pressed C");
    delay(500);
   
  }
    digitalWrite(6,HIGH);

     digitalWrite(13,LOW);
  
  if (digitalRead(8) == LOW) {
    Serial.println("Pressed *");
    delay(500);
  }
    
  if (digitalRead(9) == LOW) {
    Serial.println("Pressed 0");
    delay(500);
  }
 
  if (digitalRead(10) == LOW) {
    Serial.println("Pressed #");
    delay(500);
  }
  
  if (digitalRead(1) == LOW) {
    Serial.println("Pressed D");
    delay(500);
  }

    digitalWrite(13,HIGH);
}
