void setup() {
  pinMode(A0,OUTPUT);
  pinMode(A1,OUTPUT);
  pinMode(7,OUTPUT);
  pinMode(11,OUTPUT);
}

void loop() {
  digitalWrite(A0,HIGH);
  delay(500);
  digitalWrite(11,HIGH);
  tone(11,100,10);
  delay(500);
  digitalWrite(A0,LOW);
   digitalWrite(A1,HIGH);
  delay(500);
  digitalWrite(11,HIGH);
  tone(11,100,10);
  delay(500); 
  digitalWrite(A1,LOW);
  digitalWrite(7,HIGH);
  delay(500);
  digitalWrite(11,HIGH);
  tone(11,100,10);
  delay(500);
  digitalWrite(7,LOW);
  digitalWrite(11,LOW);
  delay(100);
}
