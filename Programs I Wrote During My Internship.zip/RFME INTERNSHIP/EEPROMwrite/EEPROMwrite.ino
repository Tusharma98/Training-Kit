#include <Wire.h>
float value = 25.75;

 byte *w = (byte *)&value;
 
void setup()
{
  Serial.begin(9600);
  Wire.begin();
  
  Wire.beginTransmission(0x51);
  Wire.write(0x00);   
  Wire.write(0x04);   

  for (int i = 0; i < 4; i++)
  {
    Wire.write(w[i]);
  }

  Wire.endTransmission();

  delay(5);
  
  
}

void loop()
{
}
