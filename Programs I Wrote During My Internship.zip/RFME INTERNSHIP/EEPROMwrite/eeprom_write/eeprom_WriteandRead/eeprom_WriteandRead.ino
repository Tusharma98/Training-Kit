#include <Wire.h>
#include <extEEPROM.h>
extEEPROM EEPROM(kbits_128, 1, 64, 0x57);


float alto;
byte *w = (byte *)&alto;
float y;
byte *r = (byte *)&y;

void setup() {
  Wire.begin();
  Serial.begin(9600);
  EEPROM.begin();
  
 
}

void loop() {
   if(Serial.available()){
    
    alto=Serial.parseFloat();
    Serial.read();
    Serial.println(alto,6);
    delay(1000);

    for (int i = 0; i < 4; i++) {
    EEPROM.write(19 + i, w[i]);  
}
    Serial.println("Write done");
   delay(1000);

   for (int i = 0; i < 4; i++) {
    r[i] = EEPROM.read(19 + i);
    
}
  Serial.println(y,6);
  Serial.println("Read done");
   }


    

}
