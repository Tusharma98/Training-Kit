#define ROWS 4
#define COLS 4

byte rowPins[ROWS] = {5, 6, 7, 8};      
byte colPins[COLS] = {9, 10, 16, 14};  

void setup() {
  Serial.begin(9600);
  while (!Serial);

  for (int r = 0; r < ROWS; r++) {
    pinMode(rowPins[r], OUTPUT);
    digitalWrite(rowPins[r], HIGH);
  }
  for (int c = 0; c < COLS; c++) {
    pinMode(colPins[c], INPUT_PULLUP);
  }
}

void loop() {
  bool pressed = false;

  for (int r = 0; r < ROWS && !pressed; r++) {
    digitalWrite(rowPins[r], LOW);

    for (int c = 0; c < COLS; c++) {
      if (digitalRead(colPins[c]) == LOW) {
        pressed = true;
        break;
      }
    }

    digitalWrite(rowPins[r], HIGH);
  }

  if (pressed) {
    Serial.println("pressed");
    delay(200); // crude debounce
  }
}
