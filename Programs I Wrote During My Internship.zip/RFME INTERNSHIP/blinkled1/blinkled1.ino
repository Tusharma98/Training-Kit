void setup(){
 pinMode(A2,OUTPUT); 
}
void loop(){
  digitalWrite(A2,HIGH);
  delay(100);
  digitalWrite(A2,LOW);
  delay(100);
}
