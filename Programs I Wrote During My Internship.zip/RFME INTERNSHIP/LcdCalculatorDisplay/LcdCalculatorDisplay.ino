#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27,2,1,0,3,4,5,6,7,POSITIVE );

 char perform;
 char once;
 float input;
 float mulint;
 float value1;
 float value2;
 float result;
void setup() {
  Serial.begin(9600);
  lcd.begin(16,2);
 
  
  pinMode(12, OUTPUT); // row
  pinMode(4, OUTPUT);
  pinMode(6, OUTPUT);
  pinMode(13, OUTPUT);

  digitalWrite(12, HIGH);
  digitalWrite(4, HIGH);
  digitalWrite(6, HIGH);
  digitalWrite(13, HIGH);

  pinMode(9, INPUT_PULLUP); // column
  pinMode(8, INPUT_PULLUP);
  pinMode(10, INPUT_PULLUP);
  pinMode(1, INPUT_PULLUP);

  
}
void loop() {
 
  digitalWrite(4,LOW);
  
  if (digitalRead(8) == LOW) {
    input=7;
    mulint=mulint*10+input;
    lcd.print(7);
    
    Serial.println("Pressed 7");
    delay(500);
  }
    
  if (digitalRead(9) == LOW) {
    input=8;
    mulint=mulint*10+input;
     lcd.print(8);
    Serial.println("Pressed 8");
    delay(500);
  } 
 
  if (digitalRead(10) == LOW) {
    input=9;
    mulint=mulint*10+input;
     lcd.print(9);
    Serial.println("Pressed 9");
    delay(500);
  }  
  
  if (digitalRead(1) == LOW) {
    perform='+';
    value1=mulint;
    mulint=0;
    lcd.print("+");
    Serial.println("Pressed +");
    delay(500);
  }


    digitalWrite(4,HIGH);

    digitalWrite(12,LOW);
  
  if (digitalRead(8) == LOW) {
    input=4;
    mulint=mulint*10+input;
    lcd.print(4);
    Serial.println("Pressed 4");
    delay(500);
  }
    
  if (digitalRead(9) == LOW) {
    input=5;
    mulint=mulint*10+input;
     lcd.print(5);
    Serial.println("Pressed 5");
    delay(500);
  } 
 
  if (digitalRead(10) == LOW) {
    input=6;
    mulint=mulint*10+input;
     lcd.print(6);
    Serial.println("Pressed 6");
    delay(500);
  }
  
  if (digitalRead(1) == LOW) {
    perform='-';
    value1=mulint;
    mulint=0;
     lcd.print("-");
    Serial.println("Pressed -");
    delay(500);
  }


    digitalWrite(12,HIGH);

     digitalWrite(6,LOW);
  
  if (digitalRead(8) == LOW) {
    input=1;
    mulint=mulint*10+input;
     lcd.print(1);
    Serial.println("Pressed 1");
    delay(500);
  }
    
  if (digitalRead(9) == LOW) {
    input=2;
    mulint=mulint*10+input;
     lcd.print(2);
    Serial.println("Pressed 2");
    delay(500);
  }
 
  if (digitalRead(10) == LOW) {
    input=3;
    mulint=mulint*10+input;
     lcd.print(3);
    Serial.println("Pressed 3");
    delay(500);
   
  }
  if (digitalRead(1)==LOW){
    perform='C';
    Serial.println("Clear");
    if(perform == 'C'){
      lcd.clear();
       input=0;
      mulint=0;
      value1=0;
      value2=0;
      result=0;
      perform=0;
      once=0;
    }
  }
    digitalWrite(6,HIGH);

    digitalWrite(13,LOW);
  
  if (digitalRead(8) == LOW) {
    perform='*';
    value1=mulint;
    mulint=0;
     lcd.print("*");
    Serial.println("Pressed *");
    delay(500);
  }

    
  if (digitalRead(9) == LOW) {
    input=0;
    mulint=mulint*10+input;
     lcd.print(0);
    Serial.println("Pressed 0");
    delay(500);
  }
 
  if (digitalRead(10) == LOW) {
    once='=';
     lcd.print("=");
    Serial.println("Pressed #");
    delay(500);
  }
  
  if (digitalRead(1) == LOW) {
    perform='/';
    value1=mulint;
    mulint=0;
    lcd.print("/");
    Serial.println("Pressed /");
    delay(500);
  }
digitalWrite(13,HIGH);



if (once == '=') {
  value2=mulint;

    if (perform == '+'){
        result = value1 + value2;
    }
    if (perform == '-'){
        result = value1 - value2;
    }
    if (perform == '*'){
        result = value1 * value2;
    }
    if (perform == '/'){
        result = value1 / value2;
    }
    lcd.clear();
    lcd.print(result,10);
    lcd.setCursor(0,2);
    Serial.println(result,10);
      
      input=0;
      mulint=0;
      value1=0;
      value2=0;
      result=0;
      perform=0;
      once=0;
      
    }
    }
    


  
