#include <Wire.h>

#define EEPROM_ADDR 0x57

void setup()
{
  Serial.begin(9600);
  while (!Serial);

  Wire.begin();

  float value = 0;
  byte *p = (byte *)&value;

  Wire.beginTransmission(EEPROM_ADDR);
  Wire.write(0x00);
  Wire.write(0x00);
  Wire.endTransmission();

  Wire.requestFrom(EEPROM_ADDR, 4);

  for (int i = 0; i < 4; i++)
  {
    while (!Wire.available());
    p[i] = Wire.read();
  }

  Serial.print("Float = ");
  Serial.println(value, 2);
}

void loop()
{
}
