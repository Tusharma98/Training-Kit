void setup(){
  pinMode(A0,OUTPUT);
  pinMode(A1,OUTPUT);
  pinMode(7,OUTPUT);
}
void loop(){
 
  digitalWrite(A0,HIGH);
  delay(500);
  digitalWrite(A0,LOW);
  digitalWrite(A1,HIGH);
  delay(500);
  digitalWrite(A1,LOW);
  digitalWrite(7,HIGH);
  delay(100);
  digitalWrite(7,HIGH);
  delay(500);
  digitalWrite(A1,HIGH);
  delay(500);
  digitalWrite(A0,HIGH);
  delay(500);
  digitalWrite(A0,LOW);
  delay(500);
  digitalWrite(A1,LOW);
  delay(500);
  digitalWrite(7,LOW);
  delay(500);
 
}
