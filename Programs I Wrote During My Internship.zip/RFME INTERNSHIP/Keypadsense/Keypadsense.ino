void setup(){
  Serial.begin(9600);
  
  pinMode(12,OUTPUT); // row 
  pinMode(4,OUTPUT);
  pinMode(6,OUTPUT);
  pinMode(13,OUTPUT);
  digitalWrite(12,LOW);
  digitalWrite(4,LOW);
  digitalWrite(6,LOW);
  digitalWrite(13,LOW);
  pinMode(9,INPUT_PULLUP); // column 
  pinMode(8,INPUT_PULLUP);
  pinMode(10,INPUT_PULLUP);
  pinMode(1,INPUT_PULLUP);
  
}
 void loop(){
    if(digitalRead(9)==LOW){
      Serial.println("Pressed on column 9");
      delay(500);
    }
    if(digitalRead(8)==LOW){
      Serial.println("Pressed on column 8");
      delay(500);
    }
    if(digitalRead(10)==LOW){
      Serial.println("Pressed on column 10");
      delay(500);
    }
    if(digitalRead(1)==LOW){
      Serial.println("Pressed on column 1");
      delay(500);
    }
 }
 
