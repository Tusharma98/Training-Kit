#include <Wire.h>
float y;
byte *r= (byte*)&y;

void setup()
{
  Serial.begin(9600);


  Wire.begin();
  Wire.beginTransmission(0x51);
  Wire.write(0x00);
  Wire.write(0x04);
  Wire.endTransmission();

  Wire.requestFrom(0x51, 4);

  for (int i = 0; i < 4; i++)
  {
    while (!Wire.available());
    r[i] = Wire.read();
  }
  Serial.println(y, 2);
}

void loop()
{
}
