
void setup(){
  pinMode(PB4,INPUT_PULLUP);
  pinMode(A0, OUTPUT);
  Serial.begin(9600);
}
void loop(){
  if(digitalRead(PB4)==LOW){
  Serial.println("pressed");
  digitalWrite(A0,HIGH);
  delay(500);
  }
  else{
    Serial.println("Not Pressed");
  }
  delay(1000);
}
