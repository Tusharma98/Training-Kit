#include <Wire.h>
#include <extEEPROM.h>
extEEPROM EEPROM (kbits_128,1,64,0x57);

  int vol;
  int var = vol+0.0;
  int Write;
  int result;
void setup(){
  Wire.begin();
  EEPROM.begin();
  Serial.begin(9600);

  
}

void loop(){
  if (Serial.available()){
  vol=Serial.parseInt();
  Serial.read();
  Serial.println(vol);

 
  for(int i=0;i<10;i++){
  EEPROM.write(32+i,vol);
}
  Serial.println("value stored in EEPROM");
  for(int i=0;i<10;i++){
  result=EEPROM.read(32+i);
  }
  Serial.println(result);
  Serial.println("value read from EEPROM");
  
  }
}
