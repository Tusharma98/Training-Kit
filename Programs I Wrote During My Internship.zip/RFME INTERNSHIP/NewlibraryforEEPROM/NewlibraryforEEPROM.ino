#include <SparkFun_External_EEPROM.h>
ExternalEEPROM EEPROM;
float y;
void setup() {
  Serial.begin(9600);
  Wire.begin();
  EEPROM.write(19,5.99);
  delay(5);
  y=EEPROM.read(19);
  Serial.println(y);
}

void loop() {
  // put your main code here, to run repeatedly:

}
