#include <Wire.h>
#include <extEEPROM.h>
extEEPROM EEPROM (kbits_128,1,64,0x57);
int i;

 String Name[30];
 String result[30];

void setup(){
  Wire.begin();
  EEPROM.begin();
  Serial.begin(9600);
  
}

void loop(){
  if(Serial.available()){
   Name=Serial.readString();
   Name.trim();
   
   Serial.println(Name[30]);
  
  for (i=0;i<10;i++){
    EEPROM.write(34+i,Name[i]);
  }
 
  Serial.println("Write done");
  
   for (i=0;i<10;i++){
   result[i] = EEPROM.read(34+i);
   }
  
  Serial.println(result[30]);
  Serial.println("Read done");
  
  }
  
}
